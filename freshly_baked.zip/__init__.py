import bpy
import os
import math
import colorsys
import numpy as np

# ------------------------------------------------------------------------
# Helper Functions
# ------------------------------------------------------------------------

def get_valid_packing_channel_count(props):
    count = 0
    if props.bake_roughness: count += 1
    if props.bake_metallic: count += 1
    if props.bake_specular: count += 1
    if props.bake_transmission: count += 1
    if props.bake_alpha: count += 1
    if props.bake_emit_strength: count += 1
    if props.bake_ao: count += 1
    if props.bake_displacement: count += 1
    if props.bake_sss: count += 1
    if props.bake_glossy: count += 1
    return count

def get_uv_layers(self, context):
    items = []
    selected_meshes = [o for o in context.selected_objects if o.type == 'MESH'] if context.selected_objects else []
    
    if not selected_meshes and context.active_object and context.active_object.type == 'MESH':
        selected_meshes = [context.active_object]

    if selected_meshes:
        uv_names = set()
        for obj in selected_meshes:
            for layer in obj.data.uv_layers:
                uv_names.add(layer.name)
        
        for name in sorted(uv_names):
            items.append((name, name, f"Use UV layer '{name}'"))

    if not items:
        items.append(('UVMap', "UVMap", "Default UV map"))

    return items

def setup_target_uv_layers(objects, target_uv_name):
    original_active_uvs = {}
    for obj in objects:
        if obj.type == 'MESH' and obj.data.uv_layers:
            original_active_uvs[obj] = obj.data.uv_layers.active.name
            uv_layer = obj.data.uv_layers.get(target_uv_name)
            if not uv_layer:
                uv_layer = obj.data.uv_layers.new(name=target_uv_name)
            obj.data.uv_layers.active = uv_layer

    def restore():
        for obj, uv_name in original_active_uvs.items():
            if obj.name in bpy.data.objects and uv_name in obj.data.uv_layers:
                obj.data.uv_layers[uv_name].active = True

    return restore

def generate_distinct_colors(n):
    colors = []
    for i in range(n):
        hue = (i * 0.618033988749895) % 1.0
        saturation = 0.85 + (i % 3) * 0.05
        value = 0.85 + (i % 2) * 0.1
        r, g, b = colorsys.hsv_to_rgb(hue, saturation, value)
        colors.append((r, g, b, 1.0))
    return colors

def prepare_temporary_override_graph(material, map_type):
    """
    Collega temporaneamente qualsiasi presa/socket target ad un nodo Emission (EMIT)
    per fare il bake accurato privo di calcoli di luce in Cycles.
    Supporta valori singoli, vettori RGB/RGBA e collegamenti da nodi precedenti.
    """
    if not material or not material.use_nodes:
        return None

    tree = material.node_tree
    bsdf = next((n for n in tree.nodes if n.type == 'BSDF_PRINCIPLED'), None)
    out_node = next((n for n in tree.nodes if n.type == 'OUTPUT_MATERIAL' and n.is_active_output), None)

    if not out_node:
        return None

    socket_to_target = None

    if map_type == 'DISPLACEMENT':
        disp_node = next((n for n in tree.nodes if n.type == 'DISPLACEMENT'), None)
        if disp_node and 'Height' in disp_node.inputs:
            socket_to_target = disp_node.inputs['Height']
    elif bsdf:
        socket_map = {
            'ROUGHNESS': ['Roughness'],
            'METALNESS': ['Metallic'],
            'SPECULAR': ['Specular IOR Level', 'Specular'],
            'ALPHA': ['Alpha'],
            'EMIT_STRENGTH': ['Emission Strength'],
            'EMISSION': ['Emission Color', 'Emission'],
            'SUBSURFACE': ['Subsurface Weight', 'Subsurface'],
        }
        if map_type in socket_map:
            possible_names = socket_map[map_type]
            for s_name in possible_names:
                if s_name in bsdf.inputs:
                    socket_to_target = bsdf.inputs[s_name]
                    break

    if not socket_to_target:
        return None

    temp_emit = tree.nodes.new(type='ShaderNodeEmission')
    temp_emit.inputs['Strength'].default_value = 1.0

    if socket_to_target.is_linked:
        from_socket = socket_to_target.links[0].from_socket
        tree.links.new(from_socket, temp_emit.inputs['Color'])
    else:
        val = socket_to_target.default_value
        if isinstance(val, (int, float)):
            temp_emit.inputs['Color'].default_value = (float(val), float(val), float(val), 1.0)
        elif hasattr(val, "__len__"):
            if len(val) == 4:
                temp_emit.inputs['Color'].default_value = val
            elif len(val) == 3:
                temp_emit.inputs['Color'].default_value = (val[0], val[1], val[2], 1.0)

    surface_socket = out_node.inputs['Surface']
    orig_surface_link = surface_socket.links[0].from_socket if surface_socket.is_linked else None
    tree.links.new(temp_emit.outputs['Emission'], surface_socket)

    def restore():
        tree.nodes.remove(temp_emit)
        if orig_surface_link:
            tree.links.new(orig_surface_link, surface_socket)

    return restore

def process_normal_map_format(image, normal_format):
    if normal_format != 'DIRECTX':
        return

    width, height = image.size
    total_pixels = width * height
    pixels = np.empty(total_pixels * 4, dtype=np.float32)
    image.pixels.foreach_get(pixels)

    # Invert Green Channel (Y-)
    pixels[1::4] = 1.0 - pixels[1::4]

    image.pixels.foreach_set(pixels)
    image.update()

def downsample_image_2x(image):
    width = image.size[0] // 2
    height = image.size[1] // 2
    image.scale(width, height)

def run_compositor_oidn(image):
    scene = bpy.context.scene
    orig_use_nodes = scene.use_nodes
    scene.use_nodes = True
    
    # Gestione sicura del node_tree del Compositor
    tree = getattr(scene, "node_tree", None)
    if tree is None and hasattr(scene, "compositor"):
        tree = scene.compositor.node_tree
    
    if not tree:
        scene.use_nodes = orig_use_nodes
        return

    tree.nodes.clear()

    node_img = tree.nodes.new(type='CompositorNodeImage')
    node_img.image = image

    node_denoise = tree.nodes.new(type='CompositorNodeDenoise')
    if hasattr(node_denoise, "use_hdr"):
        node_denoise.use_hdr = True

    node_composite = tree.nodes.new(type='CompositorNodeComposite')

    tree.links.new(node_img.outputs['Image'], node_denoise.inputs['Image'])
    tree.links.new(node_denoise.outputs['Image'], node_composite.inputs['Image'])

    scene.render.composite(tree)

    width, height = image.size
    result_pixels = np.empty(width * height * 4, dtype=np.float32)
    
    render_result = bpy.data.images.get("Render Result")
    if render_result:
        render_result.pixels.foreach_get(result_pixels)
        image.pixels.foreach_set(result_pixels)
        image.update()

    scene.use_nodes = orig_use_nodes

def create_packed_image(context, img_r, img_g, img_b, img_a, output_name):
    ref_img = next((img for img in (img_r, img_g, img_b, img_a) if img is not None), None)
    if not ref_img:
        return None

    width, height = ref_img.size
    total_pixels = width * height

    def get_channel(img, channel_index, default_val=0.0):
        if img is None:
            return np.full(total_pixels, default_val, dtype=np.float32)
        pix = np.empty(total_pixels * 4, dtype=np.float32)
        img.pixels.foreach_get(pix)
        return pix[channel_index::4]

    r_data = get_channel(img_r, 0, default_val=0.0)
    g_data = get_channel(img_g, 0, default_val=0.0)
    b_data = get_channel(img_b, 0, default_val=0.0)
    a_data = get_channel(img_a, 0, default_val=1.0) if img_a else np.ones(total_pixels, dtype=np.float32)

    packed_pixels = np.empty(total_pixels * 4, dtype=np.float32)
    packed_pixels[0::4] = r_data
    packed_pixels[1::4] = g_data
    packed_pixels[2::4] = b_data
    packed_pixels[3::4] = a_data

    packed_img = bpy.data.images.new(output_name, width=width, height=height, alpha=True, float_buffer=False)
    packed_img.colorspace_settings.name = 'Non-Color'
    packed_img.pixels.foreach_set(packed_pixels)
    packed_img.update()

    return packed_img

def save_baked_image(context, image, name_prefix, force_openexr=False):
    props = context.scene.baker_props
    base_dir = bpy.path.abspath(props.file_path)
    os.makedirs(base_dir, exist_ok=True)

    fmt = 'OPEN_EXR' if force_openexr else props.file_format
    ext_map = {'PNG': '.png', 'JPEG': '.jpg', 'OPEN_EXR': '.exr', 'TARGA': '.tga', 'TIFF': '.tif'}
    ext = ext_map.get(fmt, '.png')

    filepath = os.path.join(base_dir, f"{name_prefix}{ext}")

    orig_fmt = context.scene.render.image_settings.file_format
    orig_depth = context.scene.render.image_settings.color_depth
    orig_comp = context.scene.render.image_settings.compression
    orig_qual = context.scene.render.image_settings.quality

    try:
        context.scene.render.image_settings.file_format = fmt
        if force_openexr:
            context.scene.render.image_settings.color_depth = '32'
        else:
            context.scene.render.image_settings.color_depth = props.color_depth
            if fmt == 'PNG':
                context.scene.render.image_settings.compression = props.png_compression
            elif fmt == 'JPEG':
                context.scene.render.image_settings.quality = props.jpeg_quality

        image.save_render(filepath=filepath, scene=context.scene)
    finally:
        context.scene.render.image_settings.file_format = orig_fmt
        context.scene.render.image_settings.color_depth = orig_depth
        context.scene.render.image_settings.compression = orig_comp
        context.scene.render.image_settings.quality = orig_qual

def apply_baked_maps_to_material(obj, baked_images):
    if not obj or obj.type != 'MESH':
        return

    mat_name = f"{obj.name}_Baked_Mat"
    mat = bpy.data.materials.new(name=mat_name)
    mat.use_nodes = True
    
    if not obj.data.materials:
        obj.data.materials.append(mat)
    else:
        obj.data.materials[0] = mat

    tree = mat.node_tree
    tree.nodes.clear()

    out_node = tree.nodes.new(type='ShaderNodeOutputMaterial')
    out_node.location = (400, 0)

    bsdf = tree.nodes.new(type='ShaderNodeBsdfPrincipled')
    bsdf.location = (0, 0)
    tree.links.new(bsdf.outputs['BSDF'], out_node.inputs['Surface'])

    x_pos = -400
    y_pos = 300
    y_offset = -280

    def add_tex_node(img, colorspace, socket_name):
        nonlocal y_pos
        node = tree.nodes.new(type='ShaderNodeTexImage')
        node.image = img
        img.colorspace_settings.name = colorspace
        node.location = (x_pos, y_pos)
        
        if socket_name and socket_name in bsdf.inputs:
            tree.links.new(node.outputs['Color'], bsdf.inputs[socket_name])
            
        y_pos += y_offset
        return node

    if 'DIFFUSE' in baked_images:
        add_tex_node(baked_images['DIFFUSE'], 'sRGB', 'Base Color')

    if 'ROUGHNESS' in baked_images:
        add_tex_node(baked_images['ROUGHNESS'], 'Non-Color', 'Roughness')

    if 'METALNESS' in baked_images:
        add_tex_node(baked_images['METALNESS'], 'Non-Color', 'Metallic')

    if 'NORMAL' in baked_images:
        node = add_tex_node(baked_images['NORMAL'], 'Non-Color', None)
        norm_map = tree.nodes.new(type='ShaderNodeNormalMap')
        norm_map.location = (x_pos + 200, node.location.y)
        tree.links.new(node.outputs['Color'], norm_map.inputs['Color'])
        tree.links.new(norm_map.outputs['Normal'], bsdf.inputs['Normal'])

    if 'SPECULAR' in baked_images:
        socket = 'Specular IOR Level' if 'Specular IOR Level' in bsdf.inputs else 'Specular'
        add_tex_node(baked_images['SPECULAR'], 'Non-Color', socket)

    if 'TRANSMISSION' in baked_images:
        socket = 'Transmission Weight' if 'Transmission Weight' in bsdf.inputs else 'Transmission'
        add_tex_node(baked_images['TRANSMISSION'], 'Non-Color', socket)

    if 'SUBSURFACE' in baked_images:
        socket = 'Subsurface Weight' if 'Subsurface Weight' in bsdf.inputs else 'Subsurface'
        add_tex_node(baked_images['SUBSURFACE'], 'sRGB', socket)

    if 'ALPHA' in baked_images:
        add_tex_node(baked_images['ALPHA'], 'Non-Color', 'Alpha')

    if 'EMISSION' in baked_images:
        add_tex_node(baked_images['EMISSION'], 'sRGB', 'Emission Color')

    if 'EMIT_STRENGTH' in baked_images:
        add_tex_node(baked_images['EMIT_STRENGTH'], 'Non-Color', 'Emission Strength')

    if 'PACKED' in baked_images:
        add_tex_node(baked_images['PACKED'], 'Non-Color', None)

# ------------------------------------------------------------------------
# Dynamic Dropdown Helpers
# ------------------------------------------------------------------------

def _get_pack_channel_items(props, channel_suffix):
    items = []
    
    if channel_suffix == 'A' and props.bake_alpha:
        items.append(('ALPHA', 'Alpha', 'Alpha Map'))

    if props.bake_roughness:
        items.append(('ROUGHNESS', 'Roughness', 'Roughness Map'))
    if props.bake_metallic:
        items.append(('METALNESS', 'Metallic', 'Metallic Map'))
    if props.bake_specular:
        items.append(('SPECULAR', 'Specular', 'Specular Map'))
    if props.bake_transmission:
        items.append(('TRANSMISSION', 'Transmission', 'Transmission Map'))
    if channel_suffix != 'A' and props.bake_alpha:
        items.append(('ALPHA', 'Alpha', 'Alpha Map'))
    if props.bake_emit_strength:
        items.append(('EMIT_STRENGTH', 'Emission Strength', 'Emission Strength Map'))
    if props.bake_ao:
        items.append(('AO', 'AO', 'Ambient Occlusion Map'))
    if props.bake_displacement:
        items.append(('DISPLACEMENT', 'Displacement', 'Displacement Map'))
    if props.bake_sss:
        items.append(('SUBSURFACE', 'Subsurface', 'Subsurface Map'))
    if props.bake_glossy:
        items.append(('GLOSSY', 'Glossy', 'Glossy Map'))

    items.append((f'NONE_{channel_suffix}', 'None', 'None'))
    return items

def get_pack_r_items(self, context): return _get_pack_channel_items(self, 'R')
def get_pack_g_items(self, context): return _get_pack_channel_items(self, 'G')
def get_pack_b_items(self, context): return _get_pack_channel_items(self, 'B')
def get_pack_a_items(self, context): return _get_pack_channel_items(self, 'A')

def update_map_selection_and_packing(self, context):
    valid_count = get_valid_packing_channel_count(self)
    
    if valid_count >= 3:
        has_orm_rma = self.bake_ao and self.bake_metallic and self.bake_roughness
        if not has_orm_rma:
            self.pack_preset = 'CUSTOM'
            
            available_maps = []
            if self.bake_roughness: available_maps.append('ROUGHNESS')
            if self.bake_metallic: available_maps.append('METALNESS')
            if self.bake_specular: available_maps.append('SPECULAR')
            if self.bake_transmission: available_maps.append('TRANSMISSION')
            if self.bake_emit_strength: available_maps.append('EMIT_STRENGTH')
            if self.bake_ao: available_maps.append('AO')
            if self.bake_displacement: available_maps.append('DISPLACEMENT')
            if self.bake_sss: available_maps.append('SUBSURFACE')
            if self.bake_glossy: available_maps.append('GLOSSY')

            self.pack_r = available_maps[0] if len(available_maps) > 0 else 'NONE_R'
            self.pack_g = available_maps[1] if len(available_maps) > 1 else 'NONE_G'
            self.pack_b = available_maps[2] if len(available_maps) > 2 else 'NONE_B'
            self.pack_a = 'NONE_A'

# ------------------------------------------------------------------------
# Dynamic Presets Helper
# ------------------------------------------------------------------------

def get_pack_preset_items(self, context):
    props = getattr(context.scene, "baker_props", None)
    if not props:
        return [('CUSTOM', "Custom Packing", "Manually assign channels to R, G, B, A")]

    items = []
    if props.bake_ao and props.bake_metallic and props.bake_roughness:
        items.append(('ORM', "ORM (R: AO, G: Roughness, B: Metallic)", "Standard unreal engine / web PBR pack"))
        items.append(('RMA', "RMA (R: Roughness, G: Metallic, B: AO)", "Standard RMA packed format"))
    
    items.append(('CUSTOM', "Custom Packing", "Manually assign channels to R, G, B, A"))
    return items

# ------------------------------------------------------------------------
# Utility Operators
# ------------------------------------------------------------------------

class BAKER_OT_reset_state(bpy.types.Operator):
    bl_idname = "baker.reset_state"
    bl_label = "Force Reset UI State"
    bl_description = "Unlocks the UI if baking state got frozen"

    def execute(self, context):
        props = context.scene.baker_props
        props.is_baking = False
        props.bake_progress = 0.0
        props.bake_status_text = "Ready"
        self.report({'INFO'}, "Baker UI state reset to Ready.")
        return {'FINISHED'}

class BAKER_OT_disabled_denoise_info(bpy.types.Operator):
    bl_idname = "baker.disabled_denoise_info"
    bl_label = "Use Denoising (Disabled)"
    bl_description = "Nothing to denoise in this map selection."
    
    def execute(self, context):
        return {'FINISHED'}

class BAKER_OT_disabled_packing_info(bpy.types.Operator):
    bl_idname = "baker.disabled_packing_info"
    bl_label = "Enable Channel Packing"
    bl_description = "Select at least three valid monochrome channels to use channel packing"
    
    def execute(self, context):
        return {'FINISHED'}

class BAKER_OT_disabled_atlas_info(bpy.types.Operator):
    bl_idname = "baker.disabled_atlas_info"
    bl_label = "Atlas"
    bl_description = "Select at least two valid mesh objects to enable Atlas baking."
    
    def execute(self, context):
        return {'FINISHED'}

class BAKER_OT_open_tip_jar(bpy.types.Operator):
    bl_idname = "baker.open_tip_jar"
    bl_label = "Tips for a hair transplant"
    
    @classmethod
    def description(cls, context, properties):
        props = getattr(context.scene, "baker_props", None)
        if props and props.has_baked_once:
            return "He really needs it..."
        return "Try the service first."

    def execute(self, context):
        props = context.scene.baker_props
        if not props.has_baked_once:
            return {'CANCELLED'}
        
        bpy.ops.wm.url_open(url="https://www.paypal.me/twenty1beanies")
        return {'FINISHED'}

# ------------------------------------------------------------------------
# Property Group
# ------------------------------------------------------------------------

class BAKER_Properties(bpy.types.PropertyGroup):
    bake_mode: bpy.props.EnumProperty(
        name="Bake Mode",
        items=[
            ('DETAILS', "Details Bake", "High-to-Low Poly Normal Map Baking"),
            ('CHANNELS', "Channel Bake", "PBR Texture Baking across Single or Multiple Objects & Materials"),
        ],
        default='CHANNELS'
    )

    high_poly: bpy.props.PointerProperty(
        name="High Poly",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'MESH'
    )
    low_poly: bpy.props.PointerProperty(
        name="Low Poly",
        type=bpy.types.Object,
        poll=lambda self, obj: obj.type == 'MESH'
    )
    details_ray_distance: bpy.props.FloatProperty(
        name="Ray Distance",
        description="Max Ray Distance / Extrusion for High-to-Low baking",
        default=0.01,
        min=0.0,
        max=1.0,
        precision=4
    )

    target_uv: bpy.props.EnumProperty(
        name="Target UV",
        description="UV Layer to use for target baking",
        items=get_uv_layers
    )

    enable_atlas_bake: bpy.props.BoolProperty(
        name="Atlas",
        description="Combines UVs of all selected objects into a single Texture Atlas",
        default=False
    )
    keep_atlas_uv: bpy.props.BoolProperty(
        name="Keep Atlas UV Map",
        description="Keeps the generated Atlas UV layer on objects after baking for game engines or Blender re-use",
        default=True
    )
    atlas_counter: bpy.props.IntProperty(
        name="Atlas Counter",
        default=1
    )

    bake_diffuse: bpy.props.BoolProperty(name="Albedo / Base Color", description="Targets the Base Color socket of the Principled BSDF", default=True)
    bake_scene_light: bpy.props.BoolProperty(
        name="Bake Scene Light (Diffuse)",
        description="Includes direct and indirect lighting into the Albedo map",
        default=False
    )
    bake_roughness: bpy.props.BoolProperty(name="Roughness", description="Targets the Roughness socket of the Principled BSDF", default=True, update=update_map_selection_and_packing)
    bake_metallic: bpy.props.BoolProperty(name="Metallic", description="Targets the Metallic socket of the Principled BSDF", default=False, update=update_map_selection_and_packing)
    bake_normal: bpy.props.BoolProperty(name="Normal", description="Targets the Normal socket of the Principled BSDF", default=True)
    bake_specular: bpy.props.BoolProperty(name="Specular", description="Targets the Specular IOR Level / Specular socket of the Principled BSDF", default=False, update=update_map_selection_and_packing)
    bake_transmission: bpy.props.BoolProperty(name="Transmission", description="Targets the Transmission Weight socket of the Principled BSDF", default=False, update=update_map_selection_and_packing)
    bake_sss: bpy.props.BoolProperty(name="Subsurface", description="Targets the Subsurface Weight socket of the Principled BSDF", default=False, update=update_map_selection_and_packing)
    bake_alpha: bpy.props.BoolProperty(name="Alpha", description="Targets the Alpha socket of the Principled BSDF", default=False, update=update_map_selection_and_packing)
    bake_emit_color: bpy.props.BoolProperty(name="Emission Color", description="Targets the Emission Color socket of the Principled BSDF", default=False)
    bake_emit_strength: bpy.props.BoolProperty(name="Emission Strength", description="Targets the Emission Strength socket of the Principled BSDF", default=False, update=update_map_selection_and_packing)
    bake_ao: bpy.props.BoolProperty(name="AO / Ambient Occlusion", description="Bakes Ambient Occlusion map", default=False, update=update_map_selection_and_packing)
    bake_displacement: bpy.props.BoolProperty(name="Displacement", description="Bakes displacement map from Height or Displacement node", default=False, update=update_map_selection_and_packing)
    bake_glossy: bpy.props.BoolProperty(name="Glossy", description="Targets the Glossy BSDF reflection pass", default=False, update=update_map_selection_and_packing)
    bake_color_id: bpy.props.BoolProperty(name="Color ID / Material ID", description="Bakes high contrast Color/Material ID map", default=False)

    color_id_source: bpy.props.EnumProperty(
        name="Color ID Source",
        items=[
            ('DISTINCT', "High-Contrast Random", "Generates maximum contrast distinct colors per material"),
            ('VIEWPORT', "Viewport Display Color", "Uses the material's Viewport Display color"),
        ],
        default='DISTINCT'
    )

    normal_format: bpy.props.EnumProperty(
        name="Normal Format",
        items=[
            ('OPENGL', "OpenGL (Blender, Unity)", "Standard Y+ Normal Map"),
            ('DIRECTX', "DirectX (Unreal Engine)", "Inverted Green Channel Y- Normal Map"),
        ],
        default='OPENGL'
    )

    use_supersampling: bpy.props.BoolProperty(
        name="2x Supersampling (Anti-Aliasing)",
        description="Bakes at double resolution and downsamples for crisp anti-aliased UV edges",
        default=False
    )

    use_compositor_oidn: bpy.props.BoolProperty(
        name="Compositor OIDN Post-Pass",
        description="Runs OpenImageDenoise Compositor pass after render-denoising for crystal-clear light maps",
        default=True
    )

    combine_emission_into_diffuse: bpy.props.BoolProperty(
        name="Combine with Emission",
        description="Combines Emission Color map into the Albedo map.",
        default=False
    )
    
    enable_packing: bpy.props.BoolProperty(
        name="Enable Channel Packing",
        description="Packs baked monochrome maps into a single RGB/RGBA texture",
        default=False
    )
    discard_packed_sources: bpy.props.BoolProperty(
        name="Discard Individual Packed Maps",
        description="Deletes individual maps merged into the Packed file. Only the combined output will be saved.",
        default=False
    )
    pack_preset: bpy.props.EnumProperty(
        name="Preset",
        items=get_pack_preset_items
    )
    pack_r: bpy.props.EnumProperty(
        name="Red",
        items=get_pack_r_items
    )
    pack_g: bpy.props.EnumProperty(
        name="Green",
        items=get_pack_g_items
    )
    pack_b: bpy.props.EnumProperty(
        name="Blue",
        items=get_pack_b_items
    )
    pack_a: bpy.props.EnumProperty(
        name="Alpha",
        items=get_pack_a_items
    )

    use_denoiser: bpy.props.BoolProperty(
        name="Use Denoising",
        description="Applies Cycles denoiser on light-sampled maps.",
        default=True
    )

    apply_to_material: bpy.props.BoolProperty(
        name="Apply Textures to Material",
        description="Creates a new PBR material with baked textures and adds it as a new material slot",
        default=True
    )

    resolution: bpy.props.EnumProperty(
        name="Resolution",
        items=[
            ('1024', "1024 x 1024", "1K Texture"),
            ('2048', "2048 x 2048", "2K Texture"),
            ('4096', "4096 x 4096", "4K Texture"),
            ('8192', "8192 x 8192", "8K Texture"),
        ],
        default='2048'
    )
    auto_save: bpy.props.BoolProperty(
        name="Save Image to Disk",
        description="Automatically save generated textures to the specified path",
        default=True
    )
    file_path: bpy.props.StringProperty(
        name="Output Path",
        description="Path and file prefix (e.g. //textures/)",
        subtype='DIR_PATH',
        default="//textures/"
    )
    file_format: bpy.props.EnumProperty(
        name="Format",
        items=[
            ('PNG', "PNG", "Portable Network Graphics"),
            ('JPEG', "JPEG", "Joint Photographic Experts Group"),
            ('OPEN_EXR', "OpenEXR", "OpenEXR format"),
            ('TARGA', "Targa", "Targa image format"),
            ('TIFF', "TIFF", "Tagged Image File Format"),
        ],
        default='PNG'
    )
    color_depth: bpy.props.EnumProperty(
        name="Color Depth",
        items=[
            ('8', "8-bit", "8 bits per channel"),
            ('16', "16-bit", "16 bits per channel"),
            ('32', "32-bit", "32 bits per channel float"),
        ],
        default='16'
    )
    png_compression: bpy.props.IntProperty(name="Compression", default=15, min=0, max=100)
    jpeg_quality: bpy.props.IntProperty(name="Quality", default=90, min=0, max=100)

    is_baking: bpy.props.BoolProperty(default=False)
    bake_progress: bpy.props.FloatProperty(default=0.0, min=0.0, max=100.0)
    bake_status_text: bpy.props.StringProperty(default="Ready")
    has_baked_once: bpy.props.BoolProperty(default=False)

# ------------------------------------------------------------------------
# Details Bake Operator
# ------------------------------------------------------------------------

class BAKER_OT_bake_details(bpy.types.Operator):
    bl_idname = "baker.bake_details"
    bl_label = "Bake Normal Map"
    bl_description = "Bake Normal Map by transferring details from High-Poly to Low-Poly"

    def execute(self, context):
        props = context.scene.baker_props
        high_obj = props.high_poly
        low_obj = props.low_poly

        if not high_obj or not low_obj:
            self.report({'ERROR'}, "Please select both High-Poly and Low-Poly objects.")
            return {'CANCELLED'}

        if high_obj == low_obj:
            self.report({'ERROR'}, "High-Poly and Low-Poly must be different objects.")
            return {'CANCELLED'}

        restore_uvs = setup_target_uv_layers([low_obj], props.target_uv)

        orig_engine = context.scene.render.engine
        orig_samples = context.scene.cycles.samples
        context.scene.render.engine = 'CYCLES'
        context.scene.cycles.samples = 1

        created_nodes = []

        if not low_obj.data.materials:
            mat = bpy.data.materials.new(name=f"{low_obj.name}_Mat")
            low_obj.data.materials.append(mat)
        else:
            mat = low_obj.data.materials[0]

        mat.use_nodes = True
        nodes = mat.node_tree.nodes

        base_res = int(props.resolution)
        bake_res = base_res * 2 if props.use_supersampling else base_res
        use_float = props.color_depth in {'16', '32'}
        img_name = f"{low_obj.name}_Normal"
        
        image = bpy.data.images.new(img_name, width=bake_res, height=bake_res, float_buffer=use_float)
        image.colorspace_settings.name = 'Non-Color'

        img_node = nodes.new(type='ShaderNodeTexImage')
        img_node.image = image
        nodes.active = img_node
        created_nodes.append((mat.node_tree, img_node))

        bpy.ops.object.select_all(action='DESELECT')
        high_obj.select_set(True)
        low_obj.select_set(True)
        context.view_layer.objects.active = low_obj

        try:
            props.is_baking = True
            props.bake_progress = 10.0
            props.bake_status_text = "Baking High to Low Details..."
            context.workspace.status_text_set(props.bake_status_text)
            bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)

            bake_settings = context.scene.render.bake
            bake_settings.use_selected_to_active = True
            bake_settings.margin = 16
            
            if hasattr(bake_settings, "cage_extrusion"):
                bake_settings.cage_extrusion = props.details_ray_distance
            else:
                bake_settings.max_ray_distance = props.details_ray_distance

            bpy.ops.object.bake(type='NORMAL')
            image.update()

            process_normal_map_format(image, props.normal_format)

            if props.use_supersampling:
                downsample_image_2x(image)

            props.bake_progress = 90.0
            props.bake_status_text = "Saving Details Map..."
            bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)

            if props.auto_save:
                save_baked_image(context, image, img_name)

            if props.apply_to_material:
                apply_baked_maps_to_material(low_obj, {'NORMAL': image})

            props.has_baked_once = True
            self.report({'INFO'}, f"Details Bake completed: {img_name}")

        except Exception as e:
            self.report({'ERROR'}, f"Error during Bake: {str(e)}")
        finally:
            props.is_baking = False
            props.bake_progress = 0.0
            props.bake_status_text = "Ready"
            context.workspace.status_text_set(None)

            restore_uvs()

            for tree, node in created_nodes:
                if node in tree.nodes.values():
                    tree.nodes.remove(node)
            context.scene.render.engine = orig_engine
            context.scene.cycles.samples = orig_samples

        return {'FINISHED'}

# ------------------------------------------------------------------------
# Synchronous Channel Bake Operator
# ------------------------------------------------------------------------

class BAKER_OT_bake_channels(bpy.types.Operator):
    bl_idname = "baker.bake_channels"
    bl_label = "Bake Selected Channels"
    bl_description = "Automated PBR channel baking with Atlas, Color ID, and Anti-Aliasing"

    def execute(self, context):
        props = context.scene.baker_props
        
        for o in context.selected_objects:
            if o.type != 'MESH':
                o.select_set(False)

        target_objects = [o for o in context.selected_objects if o.type == 'MESH']
        if not target_objects:
            self.report({'ERROR'}, "Please select at least one valid Mesh object.")
            return {'CANCELLED'}

        main_obj = context.active_object if context.active_object in target_objects else target_objects[0]

        temp_atlas_created = False
        target_uv_name = props.target_uv
        atlas_uv_name = None

        if props.enable_atlas_bake and len(target_objects) > 1:
            props.bake_status_text = "Generating Texture Atlas UVs..."
            bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
            
            atlas_uv_name = f"Atlas.{props.atlas_counter:03d}"
            props.atlas_counter += 1
            
            bpy.ops.object.select_all(action='DESELECT')
            for o in target_objects:
                o.select_set(True)
                uv_layer = o.data.uv_layers.get(atlas_uv_name) or o.data.uv_layers.new(name=atlas_uv_name)
                o.data.uv_layers.active = uv_layer

            context.view_layer.objects.active = main_obj
            bpy.ops.object.mode_set(mode='EDIT')
            bpy.ops.uv.select_all(action='SELECT')
            bpy.ops.uv.pack_islands(margin=0.005)
            bpy.ops.object.mode_set(mode='OBJECT')
            temp_atlas_created = True
            target_uv_name = atlas_uv_name

        restore_uvs = setup_target_uv_layers(target_objects, target_uv_name)

        diffuse_requires_light = props.bake_diffuse and props.bake_scene_light

        maps_to_bake = []
        if props.bake_diffuse: maps_to_bake.append(('DIFFUSE', 'Albedo', 'sRGB', diffuse_requires_light))
        if props.bake_roughness: maps_to_bake.append(('ROUGHNESS', 'Roughness', 'Non-Color', False))
        if props.bake_metallic: maps_to_bake.append(('METALNESS', 'Metallic', 'Non-Color', False))
        if props.bake_normal: maps_to_bake.append(('NORMAL', 'Normal', 'Non-Color', False))
        if props.bake_specular: maps_to_bake.append(('SPECULAR', 'Specular', 'Non-Color', False))
        if props.bake_transmission: maps_to_bake.append(('TRANSMISSION', 'Transmission', 'Non-Color', True))
        if props.bake_sss: maps_to_bake.append(('SUBSURFACE', 'Subsurface', 'sRGB', False))
        if props.bake_alpha: maps_to_bake.append(('ALPHA', 'Alpha', 'Non-Color', False))
        
        if not props.combine_emission_into_diffuse and props.bake_emit_color:
            maps_to_bake.append(('EMISSION', 'EmitColor', 'sRGB', False))
        
        if props.bake_emit_strength: maps_to_bake.append(('EMIT_STRENGTH', 'EmitStrength', 'Non-Color', False))
        if props.bake_ao: maps_to_bake.append(('AO', 'AO', 'Non-Color', True))
        if props.bake_displacement: maps_to_bake.append(('DISPLACEMENT', 'Displacement', 'Non-Color', False))
        if props.bake_glossy: maps_to_bake.append(('GLOSSY', 'Glossy', 'Non-Color', True))
        if props.bake_color_id: maps_to_bake.append(('COLOR_ID', 'ColorID', 'sRGB', False))

        if not maps_to_bake:
            restore_uvs()
            self.report({'WARNING'}, "No channels selected for Baking.")
            return {'CANCELLED'}

        valid_cycles_bake_types = {'COMBINED', 'AO', 'SHADOW', 'POSITION', 'NORMAL', 'UV', 'ROUGHNESS', 'EMIT', 'ENVIRONMENT', 'DIFFUSE', 'GLOSSY', 'TRANSMISSION', 'SUBSURFACE'}

        orig_engine = context.scene.render.engine
        orig_samples = context.scene.cycles.samples
        orig_cycles_denoising = getattr(context.scene.cycles, "use_denoising", False)
        
        context.scene.render.engine = 'CYCLES'

        created_nodes = []
        baked_images_dict = {}

        props.is_baking = True
        total_maps = len(maps_to_bake)

        try:
            base_res = int(props.resolution)
            bake_res = base_res * 2 if props.use_supersampling else base_res

            for idx, (bake_type, suffix, colorspace, requires_light) in enumerate(maps_to_bake):
                props.bake_progress = (idx / total_maps) * 100.0
                props.bake_status_text = f"Baking {suffix} [{idx + 1}/{total_maps}]..."
                context.workspace.status_text_set(props.bake_status_text)
                
                bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)

                bake_settings = context.scene.render.bake
                bake_settings.use_selected_to_active = False
                bake_settings.margin = 16

                if requires_light:
                    context.scene.cycles.samples = orig_samples
                    should_denoise = props.use_denoiser
                    context.scene.cycles.use_denoising = should_denoise
                    if hasattr(bake_settings, "use_denoising"):
                        bake_settings.use_denoising = should_denoise
                else:
                    context.scene.cycles.samples = 1
                    context.scene.cycles.use_denoising = False
                    if hasattr(bake_settings, "use_denoising"):
                        bake_settings.use_denoising = False

                img_name = f"{main_obj.name}_{suffix}"
                use_float = (bake_type in {'EMIT_STRENGTH', 'DISPLACEMENT'}) or (props.color_depth in {'16', '32'})
                
                image = bpy.data.images.new(img_name, width=bake_res, height=bake_res, float_buffer=use_float)
                image.colorspace_settings.name = colorspace
                baked_images_dict[bake_type] = image

                for obj in target_objects:
                    for mat_slot in obj.material_slots:
                        if mat_slot.material and mat_slot.material.use_nodes:
                            nodes = mat_slot.material.node_tree.nodes
                            img_node = nodes.new(type='ShaderNodeTexImage')
                            img_node.image = image
                            nodes.active = img_node
                            created_nodes.append((mat_slot.material.node_tree, img_node))

                restore_callbacks = []
                
                if bake_type == 'COLOR_ID':
                    all_mats = list({slot.material for obj in target_objects for slot in obj.material_slots if slot.material})
                    distinct_colors = generate_distinct_colors(len(all_mats))
                    
                    for m_idx, mat in enumerate(all_mats):
                        tree = mat.node_tree
                        out_node = next((n for n in tree.nodes if n.type == 'OUTPUT_MATERIAL' and n.is_active_output), None)
                        if out_node:
                            temp_emit = tree.nodes.new(type='ShaderNodeEmission')
                            if props.color_id_source == 'DISTINCT':
                                temp_emit.inputs['Color'].default_value = distinct_colors[m_idx]
                            else:
                                temp_emit.inputs['Color'].default_value = (*mat.diffuse_color[:3], 1.0)
                            
                            orig_link = out_node.inputs['Surface'].links[0].from_socket if out_node.inputs['Surface'].is_linked else None
                            tree.links.new(temp_emit.outputs['Emission'], out_node.inputs['Surface'])

                            def make_restore(t=tree, o=out_node, l=orig_link, e=temp_emit):
                                return lambda: (t.nodes.remove(e), t.links.new(l, o.inputs['Surface']) if l else None)
                            
                            restore_callbacks.append(make_restore())

                elif bake_type in {'ROUGHNESS', 'METALNESS', 'SPECULAR', 'ALPHA', 'EMISSION', 'EMIT_STRENGTH', 'DISPLACEMENT', 'SUBSURFACE'}:
                    for obj in target_objects:
                        for slot in obj.material_slots:
                            if slot.material:
                                cb = prepare_temporary_override_graph(slot.material, bake_type)
                                if cb:
                                    restore_callbacks.append(cb)

                try:
                    if bake_type == 'DIFFUSE':
                        bake_settings.use_pass_direct = props.bake_scene_light
                        bake_settings.use_pass_indirect = props.bake_scene_light
                        bake_settings.use_pass_color = True
                        bake_settings.use_pass_emit = props.combine_emission_into_diffuse
                        bpy.ops.object.bake(type='DIFFUSE')

                    elif bake_type in {'ROUGHNESS', 'METALNESS', 'SPECULAR', 'ALPHA', 'EMISSION', 'EMIT_STRENGTH', 'COLOR_ID', 'DISPLACEMENT', 'SUBSURFACE'}:
                        bake_settings.use_pass_direct = False
                        bake_settings.use_pass_indirect = False
                        bake_settings.use_pass_color = True
                        bpy.ops.object.bake(type='EMIT')

                    elif bake_type in {'GLOSSY', 'TRANSMISSION'}:
                        bake_settings.use_pass_direct = True
                        bake_settings.use_pass_indirect = True
                        bake_settings.use_pass_color = True
                        bpy.ops.object.bake(type=bake_type)

                    elif bake_type == 'AO':
                        if hasattr(bake_settings, "ao_distance"):
                            bake_settings.ao_distance = 0.0
                        bpy.ops.object.bake(type='AO')

                    elif bake_type in valid_cycles_bake_types:
                        bpy.ops.object.bake(type=bake_type)

                    else:
                        self.report({'WARNING'}, f"Map type '{suffix}' is not natively supported by Cycles Bake operator. Skipping bake pass.")
                        continue

                    image.update()

                    if bake_type == 'NORMAL':
                        process_normal_map_format(image, props.normal_format)

                    if requires_light and props.use_compositor_oidn:
                        run_compositor_oidn(image)

                    if props.use_supersampling:
                        downsample_image_2x(image)

                finally:
                    for cb in restore_callbacks:
                        cb()

            # Process Channel Packing
            packed_channel_keys = set()
            valid_packing_count = get_valid_packing_channel_count(props)
            
            if props.enable_packing and valid_packing_count >= 3:
                props.bake_status_text = "Packing channels with NumPy..."
                bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)

                r_key, g_key, b_key, a_key = None, None, None, None
                pack_name_suffix = "Packed"

                if props.pack_preset == 'ORM':
                    r_key, g_key, b_key = 'AO', 'ROUGHNESS', 'METALNESS'
                    pack_name_suffix = "ORM"
                elif props.pack_preset == 'RMA':
                    r_key, g_key, b_key = 'ROUGHNESS', 'METALNESS', 'AO'
                    pack_name_suffix = "RMA"
                elif props.pack_preset == 'CUSTOM':
                    r_key = props.pack_r if not props.pack_r.startswith('NONE') else None
                    g_key = props.pack_g if not props.pack_g.startswith('NONE') else None
                    b_key = props.pack_b if not props.pack_b.startswith('NONE') else None
                    a_key = props.pack_a if not props.pack_a.startswith('NONE') else None
                    pack_name_suffix = "CustomPacked"

                for key in (r_key, g_key, b_key, a_key):
                    if key:
                        packed_channel_keys.add(key)

                img_r = baked_images_dict.get(r_key)
                img_g = baked_images_dict.get(g_key)
                img_b = baked_images_dict.get(b_key)
                img_a = baked_images_dict.get(a_key)

                packed_img_name = f"{main_obj.name}_{pack_name_suffix}"
                packed_image = create_packed_image(context, img_r, img_g, img_b, img_a, packed_img_name)

                if packed_image:
                    baked_images_dict['PACKED'] = packed_image

            # Saving Phase
            if props.auto_save:
                props.bake_status_text = "Saving Textures to Disk..."
                bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)
                
                for map_type, img in baked_images_dict.items():
                    if not img:
                        continue
                    
                    if props.enable_packing and props.discard_packed_sources and map_type in packed_channel_keys:
                        continue

                    is_hdr_strength = (map_type == 'EMIT_STRENGTH')
                    save_baked_image(context, img, img.name, force_openexr=is_hdr_strength)

            props.bake_progress = 100.0
            props.bake_status_text = "Finalizing Material..."
            bpy.ops.wm.redraw_timer(type='DRAW_WIN_SWAP', iterations=1)

            if props.apply_to_material:
                for obj in target_objects:
                    apply_baked_maps_to_material(obj, baked_images_dict)

            props.has_baked_once = True
            self.report({'INFO'}, "Successfully processed bake queue!")

        except Exception as e:
            self.report({'ERROR'}, f"Bake failed: {str(e)}")
        finally:
            props.is_baking = False
            props.bake_progress = 0.0
            props.bake_status_text = "Ready"
            context.workspace.status_text_set(None)

            restore_uvs()

            for tree, node in created_nodes:
                if node in tree.nodes.values():
                    tree.nodes.remove(node)

            if temp_atlas_created and not props.keep_atlas_uv and atlas_uv_name:
                for o in target_objects:
                    if atlas_uv_name in o.data.uv_layers:
                        o.data.uv_layers.remove(o.data.uv_layers[atlas_uv_name])

            context.scene.render.engine = orig_engine
            context.scene.cycles.samples = orig_samples
            context.scene.cycles.use_denoising = orig_cycles_denoising

        return {'FINISHED'}

# ------------------------------------------------------------------------
# UI Panel
# ------------------------------------------------------------------------

class BAKER_PT_main_panel(bpy.types.Panel):
    bl_label = "Freshly Baked v1.0"
    bl_idname = "BAKER_PT_main_panel"
    bl_space_type = 'VIEW_3D'
    bl_region_type = 'UI'
    bl_category = "Let's Cook!"

    def draw(self, context):
        layout = self.layout
        props = getattr(context.scene, "baker_props", None)

        if not props:
            layout.label(text="Error loading properties.")
            return

        row = layout.row()
        row.enabled = not props.is_baking
        row.prop(props, "bake_mode", expand=True)
        layout.separator()

        if props.is_baking:
            progress_box = layout.box()
            progress_box.label(text=props.bake_status_text, icon='TIME')
            progress_box.progress(factor=props.bake_progress / 100.0, text=f"{int(props.bake_progress)}%")
            progress_box.operator("baker.reset_state", text="Unlock UI / Cancel Frozen State", icon='CANCEL')
            layout.separator()

            col = layout.column()
            col.enabled = False
            if props.bake_mode == 'DETAILS':
                col.operator("baker.bake_details", text="Baking Details...", icon='RENDER_STILL')
            else:
                col.operator("baker.bake_channels", text="Baking Channels...", icon='RENDER_STILL')
            return

        selected_meshes = [o for o in context.selected_objects if o.type == 'MESH']
        has_multiple_meshes = len(selected_meshes) > 1

        if props.bake_mode == 'DETAILS':
            box_target = layout.box()
            box_target.label(text="Target Objects", icon='OBJECT_DATA')
            col_t = box_target.column()
            col_t.prop(props, "high_poly")
            col_t.prop(props, "low_poly")

            box_bake = layout.box()
            box_bake.label(text="Bake & Quality Settings", icon='TOOL_SETTINGS')
            col_b = box_bake.column()
            col_b.prop(props, "details_ray_distance")
            col_b.prop(props, "normal_format")
            col_b.prop(props, "resolution")
            col_b.prop(props, "use_supersampling")

            draw_export_settings(layout, props, is_details=True)

            layout.separator()
            layout.operator("baker.bake_details", text="Bake Normal Map", icon='RENDER_STILL')

        elif props.bake_mode == 'CHANNELS':
            box_uv = layout.box()
            box_uv.label(text="UV Map Setup", icon='GROUP_UVS')
            col_uv = box_uv.column()
            col_uv.prop(props, "target_uv", text="Target")
            
            if has_multiple_meshes:
                col_uv.prop(props, "enable_atlas_bake")
                if props.enable_atlas_bake:
                    col_uv.prop(props, "keep_atlas_uv")
            else:
                dis_atlas = col_uv.column()
                dis_atlas.enabled = False
                dis_atlas.operator("baker.disabled_atlas_info", text="Atlas", icon='CHECKBOX_DEHLT')

            box_setup = layout.box()
            box_setup.label(text="Textures Setup", icon='TEXTURE')
            col_pbr = box_setup.column()

            col_pbr.prop(props, "bake_diffuse")
            if props.bake_diffuse:
                col_pbr.prop(props, "bake_scene_light")
                col_pbr.prop(props, "combine_emission_into_diffuse")

            col_pbr.prop(props, "bake_roughness")
            col_pbr.prop(props, "bake_metallic")
            col_pbr.prop(props, "bake_normal")
            if props.bake_normal:
                col_pbr.prop(props, "normal_format", text="Normal Format")
            
            col_pbr.prop(props, "bake_specular")
            col_pbr.prop(props, "bake_transmission")
            col_pbr.prop(props, "bake_sss")
            col_pbr.prop(props, "bake_alpha")

            row_emit_col = col_pbr.row()
            row_emit_col.active = not props.combine_emission_into_diffuse
            row_emit_col.prop(props, "bake_emit_color")

            col_pbr.prop(props, "bake_emit_strength")
            col_pbr.prop(props, "bake_ao")
            col_pbr.prop(props, "bake_displacement")
            col_pbr.prop(props, "bake_glossy")
            col_pbr.prop(props, "bake_color_id")
            if props.bake_color_id:
                col_pbr.prop(props, "color_id_source", text="ID Palette")

            requires_light = props.bake_ao or props.bake_glossy or props.bake_transmission or (props.bake_diffuse and props.bake_scene_light)
            has_exr_notice = props.bake_emit_strength and props.auto_save

            if requires_light or has_exr_notice:
                box_setup.separator()
                col_notice = box_setup.column()
                col_notice.label(text="Bake & Export Notice:", icon='INFO')
                if requires_light:
                    col_notice.label(text=f"• Light maps use {context.scene.cycles.samples} Render Samples")
                if has_exr_notice:
                    col_notice.label(text="• Emission Strength auto-saved as 32-bit OpenEXR (.exr)")

            pack_box = layout.box()
            pack_box.label(text="Channel Packing", icon='PACKAGE')
            col_pack = pack_box.column()
            
            valid_packing_count = get_valid_packing_channel_count(props)
            if valid_packing_count >= 3:
                col_pack.prop(props, "enable_packing")
            else:
                dis_pack = col_pack.column()
                dis_pack.enabled = False
                dis_pack.operator("baker.disabled_packing_info", text="Enable Channel Packing", icon='CHECKBOX_DEHLT')

            if props.enable_packing and valid_packing_count >= 3:
                col_pack.prop(props, "discard_packed_sources")
                col_pack.prop(props, "pack_preset")
                
                has_orm_rma = props.bake_ao and props.bake_metallic and props.bake_roughness
                if not has_orm_rma and props.pack_preset in {'ORM', 'RMA'}:
                    props.pack_preset = 'CUSTOM'

                if props.pack_preset == 'CUSTOM':
                    pcol = col_pack.column()
                    pcol.prop(props, "pack_r")
                    pcol.prop(props, "pack_g")
                    pcol.prop(props, "pack_b")
                    pcol.prop(props, "pack_a")

            box_q = layout.box()
            box_q.label(text="Bake & Quality Settings", icon='TOOL_SETTINGS')
            col_q = box_q.column()
            col_q.prop(props, "resolution")
            col_q.prop(props, "use_supersampling")
            
            if requires_light:
                col_q.prop(props, "use_denoiser")
                col_q.prop(props, "use_compositor_oidn")
            else:
                dis_col = col_q.column()
                dis_col.enabled = False
                dis_col.operator("baker.disabled_denoise_info", text="Use Denoising", icon='CHECKBOX_DEHLT')

            draw_export_settings(layout, props, is_details=False)

            layout.separator()
            layout.operator("baker.bake_channels", text="Bake Selected Channels", icon='RENDER_STILL')

        layout.separator()
        tip_row = layout.row()
        tip_row.enabled = props.has_baked_once
        tip_row.operator("baker.open_tip_jar", icon='FUND')

def draw_export_settings(layout, props, is_details=False):
    box = layout.box()
    box.label(text="Output & Material Settings", icon='FILE_FOLDER')
    col = box.column()
    
    if not is_details:
        col.prop(props, "apply_to_material")
        
    col.prop(props, "auto_save")
    
    if props.auto_save:
        col.prop(props, "file_path", text="Path")
        col.prop(props, "file_format")
        col.prop(props, "color_depth")
        if props.file_format == 'PNG':
            col.prop(props, "png_compression", slider=True)
        elif props.file_format == 'JPEG':
            col.prop(props, "jpeg_quality", slider=True)

# ------------------------------------------------------------------------
# Registration
# ------------------------------------------------------------------------

classes = (
    BAKER_Properties,
    BAKER_OT_reset_state,
    BAKER_OT_disabled_denoise_info,
    BAKER_OT_disabled_packing_info,
    BAKER_OT_disabled_atlas_info,
    BAKER_OT_open_tip_jar,
    BAKER_OT_bake_details,
    BAKER_OT_bake_channels,
    BAKER_PT_main_panel,
)

def register():
    for cls in classes:
        bpy.utils.register_class(cls)
    bpy.types.Scene.baker_props = bpy.props.PointerProperty(type=BAKER_Properties)

def unregister():
    for cls in reversed(classes):
        bpy.utils.unregister_class(cls)
    if hasattr(bpy.types.Scene, "baker_props"):
        del bpy.types.Scene.baker_props

if __name__ == "__main__":
    register()